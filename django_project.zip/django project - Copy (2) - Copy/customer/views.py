from http.client import HTTPResponse
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm
from django.shortcuts import render, redirect, get_object_or_404 ,HttpResponse
from django.views import View
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
from django.db import transaction
from django.contrib.auth.mixins import LoginRequiredMixin
from .models import Category, MenuItem, Cart, CartItem, OrderDetail ,OrderItem
from django.utils.decorators import method_decorator
from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin

class LoginRequiredMessageMixin(LoginRequiredMixin):
    def dispatch(self, request, *args, **kwargs):
        if not request.user.is_authenticated:
            messages.warning(request, 'You need to log in first.')
            return redirect('login')  # Replace 'login' with the name of your login URL
        return super().dispatch(request, *args, **kwargs)

class Index(View):
    def get(self, request, *args, **kwargs):
        selected_category_id = request.GET.get('category_id')
        if selected_category_id:
            selected_category = get_object_or_404(Category, id=selected_category_id)
            menu_items = MenuItem.objects.filter(category=selected_category)
        else:
            menu_items = MenuItem.objects.all()

        categories = Category.objects.all()

        context = {
            'menu_items': menu_items,
            'categories': categories,
        }
        return render(request, 'customer/index.html', context)

class About(View):
    def get(self, request, *args, **kwargs):
        return render(request, 'customer/about.html')

class Food(View):
    def get(self, request, *args, **kwargs):
        return render(request, 'customer/food.html')

class Contact(View):
    def get(self, request, *args, **kwargs):
        return render(request, 'customer/contact.html')

class CategoryView(LoginRequiredMessageMixin, View):
    def get(self, request, category_id, *args, **kwargs):
        category = get_object_or_404(Category, id=category_id)
        menu_items = MenuItem.objects.filter(category=category)

        context = {
            'category': category,
            'menu_items': menu_items,
        }
        return render(request, 'customer/category.html', context)

    def post(self, request, category_id, *args, **kwargs):
        if request.method == 'POST':
            # Retrieve or create the cart for the logged-in user
            cart, created = Cart.objects.get_or_create(user=request.user)

            # Get the selected items from the form submission
            items = request.POST.getlist('items[]')

            for item_id in items:
                if item_id and item_id.isdigit():
                    try:
                        item = MenuItem.objects.get(id=int(item_id))
                        # Check if the item is already in the cart, update the quantity
                        cart_item, created = CartItem.objects.get_or_create(cart=cart, item=item)
                        cart_item.quantity += 1
                        cart_item.save()
                    except MenuItem.DoesNotExist:
                        pass

            messages.success(request, 'Items added to cart successfully.')
            return redirect('cart')

        category = get_object_or_404(Category, id=category_id)
        menu_items = MenuItem.objects.filter(category=category)

        context = {
            'category': category,
            'menu_items': menu_items,
        }
        return render(request, 'customer/category.html', context)
    
def add_to_cart(request, category_id):
    if request.method == 'POST':
        # Retrieve or create the cart for the logged-in user
        cart, created = Cart.objects.get_or_create(user=request.user)

        # Get the selected items from the form submission
        items = request.POST.getlist('items[]')

        for item_id in items:
            if item_id and item_id.isdigit():
                try:
                    item = MenuItem.objects.get(id=int(item_id))
            # Check if the item is already in the cart, update the quantity
                    cart_item, created = CartItem.objects.get_or_create(cart=cart, item=item)
                    if created:  # If the item is newly added to the cart, set the quantity to 1
                        cart_item.quantity = 1
                    else:  # If the item already exists in the cart, do not modify the quantity
                        pass
                        cart_item.save()
                except MenuItem.DoesNotExist:
                    pass


        messages.success(request, 'Items added to cart successfully.')
        return redirect('cart')

class Order(LoginRequiredMessageMixin, View):
    def get(self, request, *args, **kwargs):
        # Retrieve or create the cart for the logged-in user
        cart, created = Cart.objects.get_or_create(user=request.user)

        # Fetch the available menu items
        appetizers = MenuItem.objects.filter(category__name__contains='Appetizer')
        entrees = MenuItem.objects.filter(category__name__contains='Entrees')
        desserts = MenuItem.objects.filter(category__name__contains='Dessert')
        drinks = MenuItem.objects.filter(category__name__contains='Drink')
        main_dishes = MenuItem.objects.filter(category__name__contains='Main Dish')

        context = {
            'appetizers': appetizers,
            'entrees': entrees,
            'main_dishes': main_dishes,
            'desserts': desserts,
            'drinks': drinks,
            'cart': cart,
        }

        return render(request, 'customer/order.html', context)

    def post(self, request, *args, **kwargs):
        # Retrieve or create the cart for the logged-in user
        cart, created = Cart.objects.get_or_create(user=request.user)

        # Get the selected items from the form submission
        items = request.POST.getlist('items[]')

        for item_id in items:
            if item_id and item_id.isdigit():
                try:
                    item = MenuItem.objects.get(id=int(item_id))
                    # Check if the item is already in the cart, update the quantity
                    cart_item, created = CartItem.objects.get_or_create(cart=cart, item=item)
                    cart_item.quantity += 0
                    cart_item.save()
                except MenuItem.DoesNotExist:
                    pass
        for item_id in items:
            if item_id and item_id.isdigit():
                try:
                    item = MenuItem.objects.get(id=int(item_id))
                    # Check if the item is already in the cart, update the quantity
                    order_item, created = OrderItem.objects.get_or_create(cart=cart, item=item)
                    cart_item.quantity += 0
                    cart_item.save()
                except MenuItem.DoesNotExist:
                    pass

        messages.success(request, 'Items added to cart successfully.')
        return redirect('cart')

@method_decorator(csrf_exempt, name='dispatch')
class UpdateCartItemQuantity(LoginRequiredMessageMixin, View):
    def post(self, request, *args, **kwargs):
        cart_item_id = request.POST.get('cart_item_id')
        new_quantity = request.POST.get('new_quantity')

        # Validate and set default quantity
        if new_quantity is None:
            new_quantity = 1
        else:
            new_quantity = int(new_quantity)

        try:
            cart_item = CartItem.objects.get(id=cart_item_id, cart__user=request.user)
            cart_item.quantity = new_quantity
            cart_item.save()
        except CartItem.DoesNotExist:
            # Handle the case where the cart item doesn't exist
            pass

        try:
            order_item = OrderItem.objects.get(id=cart_item_id, cart__user=request.user)
            order_item.quantity = new_quantity
            order_item.save()
        except CartItem.DoesNotExist:
            # Handle the case where the cart item doesn't exist
            pass

        return JsonResponse({'message': 'Cart item quantity updated'})
    
@csrf_exempt
def remove_cart_item(request):
    if request.method == 'POST':
        cart_item_id = request.POST.get('cart_item_id')

        try:
            cart_item = CartItem.objects.get(id=cart_item_id, cart__user=request.user)
            cart_item.delete()
            return JsonResponse({'status': 'success'})
        except CartItem.DoesNotExist:
            return JsonResponse({'status': 'error', 'message': 'Cart item does not exist.'})

    return JsonResponse({'status': 'error', 'message': 'Invalid request method.'})


class SearchView(View):
    def get(self, request, *args, **kwargs):
        query = request.GET.get('query')

        if query:
            results = MenuItem.objects.filter(name__icontains=query)
        else:
            results = MenuItem.objects.none()

        context = {
            'query': query,
            'results': results,
        }

        return render(request, 'customer/search_results.html', context)
    
class CartView(LoginRequiredMessageMixin, View):
    def get(self, request, *args, **kwargs):
        # Retrieve the cart for the logged-in user
        cart = Cart.objects.get(user=request.user)

        # Retrieve the cart items for the cart
        cart_items = CartItem.objects.filter(cart=cart)

        order_items = CartItem.objects.filter(cart=cart)

        # Retrieve the menu items for the cart items
        items = [cart_item.item for cart_item in cart_items]

        context = {
            'cart': cart,
            'items': items,
        }
        order_items = [order_item.item for order_item in order_items]

        context = {
            'cart': cart,
            'order_items': order_items,
        }
        return render(request, 'customer/cart.html', context)


class Checkout(LoginRequiredMixin, View):
    def get(self, request, *args, **kwargs):
        cart = Cart.objects.get(user=request.user)
        items = request.POST.getlist('items[]')

        context = {
            'cart': cart,
            'items': items,
        }
        return render(request, 'customer/checkout.html', context)

    def post(self, request, *args, **kwargs):
        cart = Cart.objects.get(user=request.user)
        full_name = request.POST.get('full_name')
        email = request.POST.get('email')
        address = request.POST.get('address')
        city = request.POST.get('city')
        zip_code = request.POST.get('zip_code')
        phone_number = request.POST.get('phone_number')

        # Calculate the total price using the calculate_total_price method of the Cart model
        total_price = cart.calculate_total_price()

        # Create and save the OrderDetail instance with the total price
        order_detail = OrderDetail.objects.create(
            user=request.user,
            cart=cart,
            full_name=full_name,
            email=email,
            address=address,
            city=city,
            zip_code=zip_code,
            phone_number=phone_number,
            total_price=total_price,  # Set the total price in the OrderDetail
        )
        # Clear the cart after successful checkout
        cart_items = CartItem.objects.filter(cart=cart)
        cart_items.delete()

        # Display a success message
        messages.success(request, 'Your order has been placed successfully. Thank you for shopping with us!')

        return redirect('checkout_success')

class Checkout_success(LoginRequiredMessageMixin, View):
    def get(self, request, *args, **kwargs):
        return render(request, 'customer/checkout_success.html')

class SignUpView(View):
    def get(self, request, *args, **kwargs):
        form = UserCreationForm()
        context = {'form': form}
        return render(request, 'customer/signup.html', context)

    def post(self, request, *args, **kwargs):
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            messages.success(request, f'Account created for {username}. You can now log in.')
            return redirect('login')
        context = {'form': form}
        return render(request, 'customer/signup.html', context)


class LoginView(View):
    def get(self, request, *args, **kwargs):
        form = AuthenticationForm()
        context = {'form': form}
        return render(request, 'customer/login.html', context)

    def post(self, request, *args, **kwargs):
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                messages.success(request, f'Welcome back, {username}. You are now logged in.')
                return redirect('order')
        context = {'form': form}
        return render(request, 'customer/login.html', context)


class LogoutView(View):
    def post(self, request, *args, **kwargs):
        logout(request)
        messages.success(request, 'You have been logged out.')
        return redirect('index')
    

