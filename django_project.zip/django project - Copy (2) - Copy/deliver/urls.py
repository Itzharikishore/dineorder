from django.urls import path
from django.contrib import admin
from django.conf.urls.static import static
from django.conf import settings
from django.urls import path
from django.contrib.auth.views import LogoutView
from customer import views
from customer.views import Index, About,Food,Contact,Order,CartView,CategoryView,Checkout,SearchView,UpdateCartItemQuantity,LoginView,SignUpView,LogoutView,Checkout_success,remove_cart_item


urlpatterns = [
    path("admin/", admin.site.urls),
    path('category/<int:category_id>/', CategoryView.as_view(), name='category'),
    path('category/<int:category_id>/add_to_cart/',CategoryView.as_view() , name='category_add_to_cart'),



    path('', Index.as_view(), name='index'),
    path('about/', About.as_view(), name='about'),
    path('food/', Food.as_view(), name='food'),
    path('contact/', Contact.as_view(), name='contact'),
    path('order/', Order.as_view(), name='order'),
    path('cart/', CartView.as_view(), name='cart'),
    path('checkout/', Checkout.as_view(), name='checkout'),
    path('checkout_success/', Checkout_success.as_view(), name='checkout_success'),
    path('search/', SearchView.as_view(), name='search'),
    path('update_cart_item_quantity/', UpdateCartItemQuantity.as_view(), name='update_cart_item_quantity'),
    path('remove_cart_item/', remove_cart_item, name='remove_cart_item'),
    path('login/', LoginView.as_view(), name='login'),
    path('signup/', SignUpView.as_view(), name='signup'),
    path('logout/', views.LogoutView.as_view(), name='logout'),  
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)